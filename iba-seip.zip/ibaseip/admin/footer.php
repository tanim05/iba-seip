


 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

                        <p class="text-xs-center tm-footer-text"> <?php  echo "Designed & Developed by Confidence Software Limited";?></p>
                        
   </div>
					