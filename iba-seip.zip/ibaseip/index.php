<?php
// 301 Moved Permanently
header("Location: http://localhost/iba-seip/ibaseip/admin/login.php", true, 301);